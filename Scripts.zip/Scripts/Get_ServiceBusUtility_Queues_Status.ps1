﻿filter Get_All_Queues_Count  {
$AllQueueNames = Get-AzureRmServiceBusQueue -ResourceGroup TestSBMobleapp1 -NamespaceName  TestSBMobleapp1 

$AllQueueNames 
$Result = $AllQueueNames | % { @( New-Object -TypeName PSObject -Prop @{
'QueueName'= $_.Name;
'ActiveMessageCount'= $_.CountDetails.ActiveMessageCount;
'DeadLetterMessageCount'= $_.CountDetails.DeadLetterMessageCount;
'ScheduledMessageCount'= $_.CountDetails.ScheduledMessageCount;
'TransferDeadLetterM essageCount'= $_.CountDetails.TransferDeadLetterMessageCount;
'TransferMessageCount'= $_.CountDetails.TransferMessageCount;
'MaxDeliveryCount'=$_.MaxDeliveryCount;
'DeadLetteringOnMessageExpiration'=$_.DeadLetteringOnMessageExpiration;
'DefaultMessageToLive'=$_.DefaultMessageTimeToLive;
'LockDuration'= $_.LockDuration
 } 

 ) }

 $Result | select QueueName,ActiveMessageCount,DeadLetterMessageCount, ScheduledMessageCount, TransferDeadLetterMessageCount,  TransferMessageCount, MaxDeliveryCount, DeadLetteringOnMessageExpiration, DefaultMessageToLive, LockDuration  | ft 

}


filter Get_All_Topics_Count {
$AllTopicNames = Get-AzureRmServiceBusTopic -ResourceGroup TestSBMobleapp1 -NamespaceName  TestSBMobleapp1  | % { $_.Name }


$AllTopicNames | % { $mTopicName = $_ ;
$topics = Get-AzureRmServiceBusSubscription -ResourceGroup TestSBMobleapp1 -NamespaceName  TestSBMobleapp1  -TopicName $mTopicName

#$topics | % {   $_.CountDetails   }
"Topic Name ====>" + $mTopicName

$Result = $topics | % { @( New-Object -TypeName PSObject -Prop @{
'Subscriptions'= $_.Name;
'ActiveMessageCount'= $_.CountDetails.ActiveMessageCount;
'DeadLetterMessageCount'= $_.CountDetails.DeadLetterMessageCount;
'ScheduledMessageCount'= $_.CountDetails.ScheduledMessageCount;
'TransferDeadLetterM essageCount'= $_.CountDetails.TransferDeadLetterMessageCount;
'TransferMessageCount'= $_.CountDetails.TransferMessageCount;
'MaxDeliveryCount'=$_.MaxDeliveryCount;
'DeadLetteringOnMessageExpiration'=$_.DeadLetteringOnMessageExpiration;
'DefaultMessageToLive'=$_.DefaultMessageTimeToLive;
'LockDuration'= $_.LockDuration
 } 
 ) }

 $Result | select Subscriptions,ActiveMessageCount,DeadLetterMessageCount, ScheduledMessageCount, TransferDeadLetterMessageCount,  TransferMessageCount,    MaxDeliveryCount, DeadLetteringOnMessageExpiration, DefaultMessageToLive, LockDuration  | ft  -Wrap
 
 }

}

Select-AzureRmSubscription -SubscriptionName "CE Mobile Test"
#Get_All_Queues_Count 
Get_All_Topics_Count