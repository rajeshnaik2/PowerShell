﻿filter Get_All_Queues_Count  {
$AllQueueNames = Get-AzureRmServiceBusQueue -ResourceGroup Default-ServiceBus-NorthEurope -NamespaceName  ASBMobileApiProd001 

$AllQueueNames 
$Result = $AllQueueNames | % { @( New-Object -TypeName PSObject -Prop @{
'QueueName'= $_.Name;
'ActiveMessageCount'= $_.CountDetails.ActiveMessageCount;
'DeadLetterMessageCount'= $_.CountDetails.DeadLetterMessageCount;
'ScheduledMessageCount'= $_.CountDetails.ScheduledMessageCount;
'TransferDeadLetterM essageCount'= $_.CountDetails.TransferDeadLetterMessageCount;
'TransferMessageCount'= $_.CountDetails.TransferMessageCount;
'MaxDeliveryCount'=$_.MaxDeliveryCount;
'DeadLetteringOnMessageExpiration'=$_.DeadLetteringOnMessageExpiration;
'DefaultMessageToLive'=$_.DefaultMessageTimeToLive;
'LockDuration'= $_.LockDuration
 } 

 ) }

 $Result | select QueueName,ActiveMessageCount,DeadLetterMessageCount, ScheduledMessageCount, TransferDeadLetterMessageCount,  TransferMessageCount, MaxDeliveryCount, DeadLetteringOnMessageExpiration, DefaultMessageToLive, LockDuration | ft  -Wrap

}


filter Get_All_Topics_Count {
$AllTopicNames = Get-AzureRmServiceBusTopic -ResourceGroup Default-ServiceBus-NorthEurope -NamespaceName  ASBMobileApiProd001 | % { $_.Name }


$AllTopicNames | % { $mTopicName = $_ ;
    $topics = Get-AzureRmServiceBusSubscription -ResourceGroup   Default-ServiceBus-NorthEurope -NamespaceName ASBMobileApiProd001 -TopicName $mTopicName

#$topics | % {   $_.CountDetails   }
"Topic Name ====>" + $mTopicName

$Result = $topics | % { @( New-Object -TypeName PSObject -Prop @{
'Subscriptions'= $_.Name;
'ActiveMessageCount'= $_.CountDetails.ActiveMessageCount;
'DeadLetterMessageCount'= $_.CountDetails.DeadLetterMessageCount;
'ScheduledMessageCount'= $_.CountDetails.ScheduledMessageCount;
'TransferDeadLetterM essageCount'= $_.CountDetails.TransferDeadLetterMessageCount;
'TransferMessageCount'= $_.CountDetails.TransferMessageCount;
'MaxDeliveryCount'=$_.MaxDeliveryCount;
'DeadLetteringOnMessageExpiration'=$_.DeadLetteringOnMessageExpiration;
'DefaultMessageToLive'=$_.DefaultMessageTimeToLive;
'LockDuration'= $_.LockDuration
 } 
 ) }

 $Result | select Subscriptions,ActiveMessageCount,DeadLetterMessageCount, ScheduledMessageCount, TransferDeadLetterMessageCount,  TransferMessageCount,    MaxDeliveryCount, DeadLetteringOnMessageExpiration, DefaultMessageToLive, LockDuration  | ft  -Wrap
 
 }

}

Select-AzureRmSubscription -SubscriptionName "CE Ticketing App Production"
Get_All_Queues_Count 
Get_All_Topics_Count