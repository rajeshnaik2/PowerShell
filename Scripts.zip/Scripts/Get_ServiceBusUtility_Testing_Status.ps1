﻿filter Get_All_Topics_Count {
$AllTopicNames = Get-AzureRmServiceBusTopic -ResourceGroup Default-ServiceBus-NorthEurope -NamespaceName  ASBMobileApiProd001 | % { $_.Name }


$AllTopicNames | % { $mTopicName = $_ ;
    $topics = Get-AzureRmServiceBusSubscription -ResourceGroup   Default-ServiceBus-NorthEurope -NamespaceName ASBMobileApiProd001 -TopicName $mTopicName

#$topics | % {   $_.CountDetails   }
"Topic Name ====>" + $mTopicName

$Result = $topics | % { @( New-Object -TypeName PSObject -Prop @{
'Subscriptions'= $_.Name;
'ActiveMessageCount'= $_.CountDetails.ActiveMessageCount;
'DeadLetterMessageCount'= $_.CountDetails.DeadLetterMessageCount;
'ScheduledMessageCount'= $_.CountDetails.ScheduledMessageCount;
'TransferDeadLetterM essageCount'= $_.CountDetails.TransferDeadLetterMessageCount;
'TransferMessageCount'= $_.CountDetails.TransferMessageCount;
 } 
 ) }

 $Result | select Subscriptions,ActiveMessageCount,DeadLetterMessageCount, ScheduledMessageCount, TransferDeadLetterMessageCount,  TransferMessageCount   | ft 
 
 }

}

Select-AzureRmSubscription -SubscriptionName "CE Ticketing App Production"
Get_All_Topics_Count 