﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.ServiceBus.Messaging;
using Newtonsoft.Json;

namespace MobileAppServiceBus.DeadLetterQueueReader
{

    public class data
    {
        public string Body { get; set; }

    }

    class Program
    {
        static void Main(string[] args)
        {
            var connectionString = "Endpoint=sb://testsbmobleapp1.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=DiWmCfhaR4t6J0qeMov6XjOdKmcK0UAEbwqeImouP3s=";
            var queueName = "queuetest1";

            //var client = QueueClient.CreateFromConnectionString(connectionString, queueName);
            //var message = new BrokeredMessage("This is a test message!");


            //Console.WriteLine(String.Format("Message body: {0}", message.GetBody<String>()));
            //Console.WriteLine(String.Format("Message id: {0}", message.MessageId));

            //client.Send(message);

            //Console.WriteLine("Message successfully sent! Press ENTER to exit program");
            //Console.ReadLine();


            List<data> _data = new List<data>();

            string deadLetterQueueName = queueName + "/$DeadLetterQueue";
            QueueClient client_dl = QueueClient.CreateFromConnectionString(connectionString, deadLetterQueueName);
            // do whatever regular queue reading activities

            QueueClient deadLetterClient = QueueClient.CreateFromConnectionString(connectionString, QueueClient.FormatDeadLetterPath(client_dl.Path), ReceiveMode.PeekLock);

            BrokeredMessage receivedDeadLetterMessage ;
            while ((receivedDeadLetterMessage = client_dl.Receive(TimeSpan.FromSeconds(10)) ) != null)
            {
                string msgBody = receivedDeadLetterMessage.GetBody<String>();
                Console.WriteLine(String.Format("Message body: {0}", msgBody));
                Console.WriteLine(String.Format("Message id: {0}", receivedDeadLetterMessage.MessageId));
                Console.WriteLine(String.Format("Message id: {0}", receivedDeadLetterMessage.SequenceNumber));
                Console.WriteLine(String.Format("Message id: {0}", receivedDeadLetterMessage.Size));
                Console.WriteLine(String.Format("Message id: {0}", receivedDeadLetterMessage.MessageId));
                Console.WriteLine(String.Format("Message id: {0}", receivedDeadLetterMessage.Label));
                Console.WriteLine(String.Format("Message id: {0}", receivedDeadLetterMessage.EnqueuedTimeUtc));
                Console.WriteLine(String.Format("Message id: {0}", receivedDeadLetterMessage.ExpiresAtUtc));

                _data.Add(new data()
                {
                   Body = msgBody
                });
            }

            //var message = client_dl.Receive();
            //var queues = namespaceManager.GetQueues()
            //.Where(q => q.MessageCountDetails.DeadLetterMessageCount > 0);

            using (System.IO.StreamWriter file = File.CreateText(@"D:\TestBackupDeadLetterQueue.json"))
            {
                JsonSerializer serializer = new JsonSerializer();
                //serialize object directly into file stream
                serializer.Formatting = Formatting.Indented;
                serializer.Serialize(file, _data );
            }

            Console.WriteLine("Message successfully read ! Press ENTER to continue");


        }
    }
}
